package $package_name$.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import $package_name$.R;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}